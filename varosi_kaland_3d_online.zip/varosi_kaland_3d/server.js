const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.use(express.static(path.join(__dirname, 'public')));
const players = new Map();
io.on('connection', socket => {
  players.set(socket.id, {x:0,z:0,rot:0,car:false});
  socket.on('move', p => {
    if (!p || !Number.isFinite(p.x) || !Number.isFinite(p.z) || !Number.isFinite(p.rot)) return;
    players.set(socket.id, {x:Math.max(-330,Math.min(330,p.x)),z:Math.max(-330,Math.min(330,p.z)),rot:p.rot,car:!!p.car});
  });
  socket.on('disconnect', () => players.delete(socket.id));
});
setInterval(() => io.emit('state', Object.fromEntries(players)), 80);
const port = process.env.PORT || 3000;
server.listen(port, '0.0.0.0', () => console.log(`Varosi KalAnd 3D fut: http://localhost:${port}`));
