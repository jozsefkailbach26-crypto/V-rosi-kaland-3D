# Városi Kaland 3D Online

Ez egy induló, 3D-s böngészős városi sandbox prototípus mobilos érintőgombokkal és Socket.IO alapú játékos-szinkronnal.

## Indítás számítógépen
1. Telepíts Node.js 18 vagy újabb verziót.
2. A projekt mappájában futtasd: `npm install`
3. Futtasd: `npm start`
4. Nyisd meg: `http://localhost:3000`

## Online többjátékos
A projektet olyan Node.js tárhelyre kell telepíteni, amely támogatja a tartós webes kapcsolatokat / Socket.IO-t. A tárhely által adott HTTPS URL-t nyisd meg minden játékos telefonján.

## Megjegyzések
- A Three.js könyvtár CDN-ről töltődik be, ezért internet szükséges.
- Ez prototípus, nem kész GTA-klón: nincs küldetésrendszer, rendőrség, fegyverrendszer, mentés vagy kész játékosfiók.
- A multiplayer jelenleg pozíciókat szinkronizál, nem csalásbiztos és nincs fiók-/szobakezelés.
- A GTA és a Rockstar Games védjegyei, tartalmai nincsenek beépítve.
